import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent {

  events=[
    {
      title:"Sunburn Goa 2019",
      eventdate:"Dec 27",
      src:"https://in.bmscdn.com/Events/moviecard/sunburn-goa-2019-et00104928-2019-12-12-t-22-3-19.jpg"
    },
    {
      title:"HCF'19 ft Vipul Goyal",
      eventdate:"Jan 04",
      src:"https://in.bmscdn.com/Events/moviecard/hcf19-ft-vipul-goyal-et00114855-2019-10-18-t-13-26-59.jpg"
    },
    {
      title:"Fresher Thoughts by Kunal K",
      eventdate:"Dec 20",
      src:"https://in.bmscdn.com/Events/moviecard/fresher-thoughts-by-kunal-kamra-for-the-last-time-et00115483-2019-10-30-t-19-14-7.jpg"
    },
    {
      title:"Jealous of Sabjiwala",
      eventdate:"Feb 15",
      src:"https://in.bmscdn.com/Events/moviecard/jealous-of-sabjiwala-standup-by-abhishek-upmanyu-et00114876-2019-10-18-t-19-28-26.jpg"
    },
    {
      title:"Once Sapan A Time",
      eventdate:"Feb 08",
      src:"https://in.bmscdn.com/Events/moviecard/once-sapan-a-time-et00114881-2019-10-16-t-16-50-29.jpg"
    },
    {
      title:"Friday Night Live",
      eventdate:"Dec 27",
      src:"https://in.bmscdn.com/Events/moviecard/friday-night-live-ft-jammers-et00118349-2019-12-12-t-17-46-56.jpg"
    },
  ]

}
