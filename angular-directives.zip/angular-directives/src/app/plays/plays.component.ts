import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plays',
  template:`
  <style>
  .horizontal {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
}
li{
    list-style-type:none;
}
  </style>
  <ul>
    <div class="horizontal">
    <li *ngFor="let play of plays"><img src={{play.src}} height=250><br>{{play.title}}<br>{{play.playtime}}</li>
    </div>
  </ul>
  `,
  styleUrls: ['./plays.component.css']
})
export class PlaysComponent {

  plays=[
    {
      title:"Badlav",
      playtime:"Dec 21",
      src:"https://in.bmscdn.com/Events/moviecard/badlav-et00117908-2019-11-20-t-18-19-55.jpg"
    },
    {
      title:"TM-Potle",
      playtime:"Dec 19",
      src:"https://in.bmscdn.com/Events/moviecard/tm-potle-the-missing-pieces-of-your-tiny-little-et00117910-2019-11-21-t-14-23-0.jpg"
    },
    {
      title:"Mahabharat",
      playtime:"Jan 04",
      src:"https://in.bmscdn.com/Events/moviecard/mahabharata-the-epic-tale-et00104211-2019-10-13-t-19-53-30.jpg"
    },
    {
      title:"Almost Flawless",
      playtime:"Dec 29",
      src:"https://in.bmscdn.com/Events/moviecard/sifars-almost-flawless-et00120485-2019-12-16-t-17-35-17.jpg"
    },
    {
      title:"Round & Round & Round",
      playtime:"Dec 28",
      src:"https://in.bmscdn.com/Events/moviecard/sifars-round-and-round-and-round-et00102639-2019-12-16-t-17-52-47.jpg"
    },
    {
      title:"Acute Angle",
      playtime:"Dec 22",
      src:"https://in.bmscdn.com/Events/moviecard/acute-angle-an-original-english-play-et00119556-2019-12-9-t-18-30-55.jpg"
    },
  ]

}
