import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template:`<h1>Directives Example</h1>
  <app-events></app-events>
  <app-plays></app-plays>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-directives';
}
